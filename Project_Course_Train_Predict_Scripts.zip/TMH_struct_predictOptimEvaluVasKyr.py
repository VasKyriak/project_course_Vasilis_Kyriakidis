########################################## Structure Prediction Model for Parameter Optimization ##########################################


###################### Opening Output file for Classification Report ######################

out = open('ClassificationReport.txt', 'a')

###################### Prefered window size ######################

window_size = [29, 31, 33, 35, 37]

### window size optional input
### win = int(input('Type your odd number window size: ')

for win in window_size:
	fo = open ('307of614_seq_set.txt', 'r')

###################### Padding: Function for zeros added at the beginning and the end of the sequence ###################### 

	win_extra = int(win/2 - 0.5) 
	#print ("Padding %d" %win_extra)

###################### Creating lists for seq IDs, aminoacids, features and the input file ###################### 

	list_ID = list()
	list_amino = list()
	list_struct = list()
	list_word = list()
	list_all = list()

###################### Remove line breaks in Input File ###################### 

	for line in fo:
		newline = line.replace('\n', '')
		list_all.append(newline)
	print ("Length of Sequence List:%d" %len(list_all))

	#print(list_all)

###################### For all appended lists, there is a pattern in our dataset where the first line is the ID, the second line is the seq and the third line are the features. So we append the lists according to that pattern. So we append the first, second, or third line in each list and then the line needed is every third line after that one ###################### 

	for i in range (0, len(list_all), 3):
		list_ID.append(list_all[i])

###################### Appending the aminoacid list by also padding with zeros in the beginning and the end of the seq because we always need the middle residue in order to associate the window with a feature ######################

	#print ("Appending AminoAcid list")
	for i in range (1, len(list_all), 3):
		seq = '0'*win_extra + list_all[i] + '0'*win_extra 
		list_amino.append(seq)
		for j in range(win_extra,len(seq)-win_extra):
			win_new = seq[j-win_extra:j+win_extra+1]
			list_word.append(win_new)
	#print (len(list_word))

	for i in range (2, len(list_all), 3):
		list_struct.append(list_all[i])

###################### Mapping/converting features to numbers ###################### 

	#print ("Mapping features to numbers...")
	map = {'G': 1, 'M': 2, 'I':3, 'O':3}
	features = ''.join(list_struct)
	features = [char for char in features]
	features = [map[i] for i in features]
	#print (features)

###################### Mapping/converting aminoacids to numbers ###################### 

	#print ("Mapping AA to numbers...")
	map = {'A': 1, 'C':2, 'D':3, 'E':4,'F':5, 'G':6, 'H':7, 'I':8, 'K':9, 'L':10, 'M':11, 'N':12, 'P':13, 'Q':14, 'R':15, 'S':16, 'T':17, 'V':18, 'W':19, 'Y':20, 'X':21, '0':0}

###################### Creating windows corresponding to each feature ###################### 

	windfeat = []
	for element in list_word:
		temp = []
		for char in element:
			feat = map[char]
			temp.append(feat)
		windfeat.append(temp)
	#print ("Processed the windows, length:%d" %(len(windfeat)))
	#print (windfeat)
	
###################### One-Hot encoding ###################### 

	from sklearn import preprocessing 
	enc= preprocessing.OneHotEncoder()
	enc.fit(windfeat)
	windfeat = enc.transform(windfeat).toarray()

	#print (len(features))
	#print (windfeat)

###################### SVM fit, Cross Validation and Parameter Estimation Using Grid Search  ###################### 
	
	import time
	start = time.time()
	
	from sklearn import svm
	from sklearn.svm import SVC
	from sklearn.model_selection import train_test_split
	from sklearn.metrics import classification_report
	from sklearn.model_selection import cross_val_predict
	from sklearn import svm, datasets
	from sklearn.model_selection import GridSearchCV
	
                 ##### Fit #####
	X_train, X_test, y_train, y_test = train_test_split(windfeat, features, random_state=0)
	lin_clf = svm.LinearSVC(class_weight = 'balanced')
	lin_clf.fit(windfeat, features)

				##### Predict with Cross Validatation #####
	predicted = cross_val_predict(lin_clf, windfeat, features, cv=3)

				##### Grid Search #####
	parameters = {'C':[1, 10, 15, 25, 100]}
	lin_clf = GridSearchCV(svm.LinearSVC(), parameters, scoring='f1_macro')
	lin_clf.fit(windfeat, features)
	best_params_ = lin_clf.best_params_
	best_score_ = lin_clf.best_score_

	print ("Best Parameteres are: %r" %best_params_)
	print ("Best Score is: %r" %best_score_)

				##### Print and Write Classification Report #####
	end = time.time()
	out.write('\n' + str(win)+'\n'+ "Best Parameteres are: %r" %best_params_ + '\n'+ "Best Score is: %r" %best_score_ + '\n')
	out.write(classification_report(features, predicted))
	print (classification_report(features, predicted))
	print("Window size %s took %s seconds"%(str(win), str((end-start))))

###################### Confusion Matrix ######################

	import itertools
	import numpy as np
	import matplotlib
	matplotlib.use('Agg')
	import matplotlib.pyplot as plt
	from sklearn import svm, datasets
	from sklearn.model_selection import train_test_split
	from sklearn.metrics import confusion_matrix

	title = ('Confusion matrix')
	classes = ('G', 'M', 'I/O')

	X_train, X_test, y_train, y_test = train_test_split(windfeat, features, random_state=0)
	lin_clf = svm.LinearSVC(class_weight = 'balanced')
	lin_clf.fit(windfeat, features)
	predicted=lin_clf.predict(X_test)


	cm= confusion_matrix(y_test, predicted)
	cmap=plt.cm.Blues


	plt.imshow(cm, interpolation='nearest', cmap=cmap)
	plt.title(title)
	plt.colorbar()
	tick_marks = np.arange(len(classes))
	plt.xticks(tick_marks, classes, rotation=45)
	plt.yticks(tick_marks, classes)


	cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
	thresh = cm.max() / 2.
	for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
		plt.text(j, i, round(cm[i, j], 2),
			     horizontalalignment="center",
			     color="white" if cm[i, j] > thresh else "black")

	np.set_printoptions(precision=2)

	plt.tight_layout()
	plt.ylabel('True')
	plt.xlabel('Predicted')
	plt.savefig(str(win)+'.png')

###################### Close Output File ######################

out.close()

###################### END ######################
