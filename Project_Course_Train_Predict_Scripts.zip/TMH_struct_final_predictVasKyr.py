########################################## Protein Structure Predictor ##########################################

###################### START ######################

print('Transmembrane Protein Topology Predictor')
print()

###################### Input of the sequence file ###################### 

input_file = input('Insert Protein Sequence File Directory for Structure Prediction: ')
input_file = open (input_file, 'r')

###################### Prefered window size and and Padding function ###################### 

win = 45
win_extra = int(win/2 - 0.5) 

###################### Creating lists for sequence IDs, aminoacids, features and words ###################### 

list_ID = list()
list_amino = list()
list_struct = list()
list_word = list()

###################### Create list to append input file ###################### 

list_all = list()

###################### Remove line breaks ###################### 

for line in input_file:
	newline = line.replace('\n', '')
	list_all.append(newline)

###################### Appending all lists ###################### 

	### Append ID list ###
for i in range (0, len(list_all), 2):
		list_ID.append(list_all[i])

	### Appending the aminoacid list ### 
	# Note: We need the middle residue in order to associate the window with a feature, so we put zeros in the beginning and the end of the seq to fill in the gaps for the first and last residues in 		the seq #

for i in range (1, len(list_all), 2):
	seq = '0'*win_extra + list_all[i] + '0'*win_extra 
	list_amino.append(seq)
	for j in range(win_extra,len(seq)-win_extra):
		win_new = seq[j-win_extra:j+win_extra+1]
		list_word.append(win_new)

###################### Mapping/converting features to numbers ###################### 

'''map = {'G': 1, 'M': 2, 'I':3, 'O':3}
features = ''.join(list_struct)
features = [char for char in features]
features = [map[i] for i in features]'''

###################### Mapping/converting aminoacids to numbers ###################### 

map = {'A': 1, 'C':2, 'D':3, 'E':4,'F':5, 'G':6, 'H':7, 'I':8, 'K':9, 'L':10, 'M':11, 'N':12, 'P':13, 'Q':14, 'R':15, 'S':16, 'T':17, 'V':18, 'W':19, 'Y':20, 'X':21, '0':0}

###################### Creating windows ###################### 

windfeat = []
for element in list_word:
	temp = []
	for char in element:
		feat = map[char]
		temp.append(feat)
	windfeat.append(temp)
	
###################### One-Hot Encoding ###################### 

from sklearn import preprocessing 

enc= preprocessing.OneHotEncoder(n_values = 23)
enc.fit(windfeat)
windfeat = enc.transform(windfeat).toarray()

###################### Machine Learning ######################

from sklearn import svm
from sklearn.svm import SVC
from sklearn.externals import joblib
from sklearn import datasets
import numpy as np

print()
#input_train = input('Insert training model directory: ')
ml = joblib.load('TMH_Train_Model')
pred_str = ml.predict(windfeat)

###################### Features Map Inversion ######################

inv_map = {1:'G', 2:'M', 3:'L'}	
pred_struct = [inv_map[numbers] for numbers in pred_str]	

###################### Predict Structure ######################

	### Remove pads ###
list_seq = []		
for element in list_amino:
	seq_new = element.replace('0', '')
	list_seq.append(seq_new)

	### Create File of Prediction and Print ###
final_struct = list()
for i in range (0, len(list_seq)):
	ps = str()
	for char in range (0, len(list_seq[i])):
		ps = ps + pred_struct[0]
		pred_struct.remove(pred_struct[0])

	final_struct.append(ps)

zip_list = list(zip(list_ID, list_seq, final_struct))
pred = open('PredictedStructures.txt', 'w')
pred.write('########## Predicted Protein Structures ########## \n \n### Note: L = Transmembrane Protein Location (Inside or Outside) ### \n \n')

for i in range(0,len(zip_list)):
	for j in range (0, len(zip_list[i])):
		pred.write(str(zip_list[i][j]) + '\n')
		print (zip_list[i][j])
	print()
	print('L : Transmembrane Protein Location (Inside or Outside)')
	print()
pred.close()

###################### END ######################
