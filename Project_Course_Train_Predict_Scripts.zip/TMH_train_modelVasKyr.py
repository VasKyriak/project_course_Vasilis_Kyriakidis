########################################## Training Model ##########################################

###################### Input of the sequence file ###################### 

#fo = open ('307of614_seq_set.txt', 'r')
input_file = input('Insert Protein Sequence File directory to train: ')
input_file = open (input_file, 'r')

###################### Prefered window size and function for zeros added at the beginning and the end of the sequence ###################### 

win = 45
win_extra = int(win/2 - 0.5) 

###################### Creating lists for seq IDs, aminoacids, and features ###################### 

list_ID = list()
list_amino = list()
list_struct = list()
list_word = list()

###################### Create list to append the entire file ###################### 

list_all = list()

###################### Remove line breaks ###################### 

for line in input_file:
	newline = line.replace('\n', '')
	list_all.append(newline)

###################### For all lists we are appending, we have a pattern from our dataset where the first line is the ID, the second line is the seq and the third line are the features. So we append the lists according to that pattern. We tell the program toput in each list the first, second, or third line and then the line we need is every third line after that ###################### 

for i in range (0, len(list_all), 3):
		list_ID.append(list_all[i])

###################### Appending the aminoacid list. We always need the middle residue in order to associate the window with a feature, so we put zeros in the beginning and the end of the seq to fill in the gaps for the first and last residues in the seq ###################### 

for i in range (1, len(list_all), 3):
	seq = '0'*win_extra + list_all[i] + '0'*win_extra 
	list_amino.append(seq)
	for j in range(win_extra,len(seq)-win_extra):
		win_new = seq[j-win_extra:j+win_extra+1]
		list_word.append(win_new)

for i in range (2, len(list_all), 3):
	list_struct.append(list_all[i])

###################### Mapping/converting features to numbers ###################### 

map = {'G': 1, 'M': 2, 'I':3, 'O':3}
features = ''.join(list_struct)
features = [char for char in features]
features = [map[i] for i in features]

###################### Mapping/converting aminoacids to numbers ###################### 

map = {'A': 1, 'C':2, 'D':3, 'E':4,'F':5, 'G':6, 'H':7, 'I':8, 'K':9, 'L':10, 'M':11, 'N':12, 'P':13, 'Q':14, 'R':15, 'S':16, 'T':17, 'V':18, 'W':19, 'Y':20, 'X':21, '0':0}

###################### Creating windows ###################### 

windfeat = []
for element in list_word:
	temp = []
	for char in element:
		feat = map[char]
		temp.append(feat)
	windfeat.append(temp)
	
###################### One-Hot Encoding ###################### 

from sklearn import preprocessing 
enc= preprocessing.OneHotEncoder(n_values = 23)
enc.fit(windfeat)
windfeat = enc.transform(windfeat).toarray()

###################### SVM fit ###################### 

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.model_selection import cross_val_predict
from sklearn import svm

lin_clf = svm.LinearSVC(class_weight = 'balanced')
lin_clf.fit(windfeat, features)

from sklearn.externals import joblib
joblib.dump(lin_clf, 'TMH_Train_Model')

###################### END ###################### 
